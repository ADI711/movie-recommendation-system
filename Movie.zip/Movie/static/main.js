const form = document.querySelector('form');
const input = document.querySelector('input[type="text"]');
const ul = document.querySelector('ul');

form.addEventListener('submit', (e) => {
    e.preventDefault();
    const movie_title = input.value;
    fetch('/recommendation', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            movie_title: movie_title
        })
    })
        .then(response => response.json())
        .then(data => {
            // Extract the recommended movies from the response data
            const CS_recommended_movies = data.CS_recommended_movies;
            const CC_recommended_movies = data.CC_recommended_movies;
            const KNM_recommended_movies = data.KNM_recommended_movies;

            // Combine the recommended movies into a single array
            const recommendedMovies = [
                ...CS_recommended_movies,
                ...CC_recommended_movies,
                ...KNM_recommended_movies
            ];

            ul.innerHTML = '';
            recommendedMovies.forEach(movie => {
                const li = document.createElement('li');
                li.textContent = movie;
                ul.appendChild(li);
            })
        })
        .catch(error => {
            console.error('Error:', error);
        });
});
