This is a movie recommendation system using python flask and it has 3 algorithms in it
- cosine similarity
- correlation coefficient
- k - means clustering

To run this file just download the required libraries and run the main python file.

after a output is generated go back to localhost:5000 each time to enter a new movie.