import pandas as pd
import numpy as np
from flask import Flask, render_template, request
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.cluster import KMeans
from sklearn.metrics.pairwise import cosine_similarity


def create_cosine_similarity():
    data = pd.read_csv('main_data.csv')
    # creating a count matrix
    cv = CountVectorizer()
    count_matrix = cv.fit_transform(data['comb'])
    # creating a similarity score matrix
    similarity = cosine_similarity(count_matrix)
    return data,similarity

def cs_rcmd(movie):
    movie = movie.lower()
    try:
        data, similarity = create_cosine_similarity()
    except:
        data.head()
        similarity.shape
    if movie not in data['movie_title'].unique():
        return('Sorry! The movie you requested is not in our database. Please check the spelling or try with some other movies')
    else:
        i = data.loc[data['movie_title']==movie].index[0]
        lst = list(enumerate(similarity[i]))
        lst = sorted(lst, key = lambda x:x[1] ,reverse=True)
        lst = lst[1:11] # excluding first item since it is the requested movie itself
        similar_movies = []
        for i in range(len(lst)):
            a = lst[i][0]
            similar_movies.append(data['movie_title'][a])
        return similar_movies

# Create recommendation engine
def get_recommendations_usingCorr(movie_index, similarity_matrix, movies_df):
    similar_movies = similarity_matrix[movie_index]
    movie_indices = np.argsort(similar_movies)[::-1]
    recommended_movies = []
    for i in movie_indices:
        if i == movie_index:
            continue
        recommended_movies.append(movies_df.iloc[i]['movie_title'])
        if len(recommended_movies) == 10:
            break
    return recommended_movies

# using correlation-coefficient to recommend
def correlationCoefficient_rcmd(movie):
    # Load movie dataset
    movies_df = pd.read_csv("movie_metadata.csv")
    movies_df['movie_title'] = movies_df['movie_title'].str.lower()
    # removing the null terminating char at the end
    movies_df['movie_title'] = movies_df['movie_title'].apply(lambda x : x[:-1])

    # Preprocess data
    movies_df.drop_duplicates(inplace=True)
    movies_df.dropna(inplace=True)

    # Create feature matrix
    features = ['num_critic_for_reviews', 'duration', 'director_facebook_likes', 'actor_3_facebook_likes',
                'actor_1_facebook_likes', 'gross', 'num_voted_users', 'cast_total_facebook_likes',
                'facenumber_in_poster', 'num_user_for_reviews', 'budget', 'title_year', 'actor_2_facebook_likes',
                'imdb_score', 'aspect_ratio', 'movie_facebook_likes']
    matrix = pd.get_dummies(movies_df[features]).values

    # Calculate similarity matrix using correlation coefficient
    similarity_matrix = np.corrcoef(matrix)

    # Get the movie index
    movie_index_range = list(movies_df['movie_title'])
    user_movie = movie.lower()
    movie_index = 0
    i = 0
    for i in range(0,len(movie_index_range)):
        if movie_index_range[i] == user_movie:
            movie_index = i
            break

    if user_movie not in movies_df['movie_title'].unique():
        return('Sorry! The movie you requested is not in our database. Please check the spelling or try with some other movies')

    recommended_movies = get_recommendations_usingCorr(movie_index, similarity_matrix, movies_df)
    return recommended_movies

# Define a function to recommend movies to the user based on their previously rated movies
def get_KNNrecommend_movies(movie_title,movies_df):

    # Get the movie index
    movies_list = list(movies_df['movie_title'])
    movie_index = 0
    i = 0
    for i in range(0,len(movies_list)):
        if movies_list[i] == movie_title.lower():
            movie_index = i
            break
    # Get the cluster number of the previously rated movie
    cluster_label = movies_df.iloc[movie_index]['cluster']

    # Filter the movies dataframe based on the cluster number of the previously rated movie
    cluster_movies = movies_df[movies_df['cluster'] == cluster_label]['movie_title'].tolist()

    # Remove the previously rated movie from the list of recommended movies
    # cluster_movies.remove(movie_title)
    cluster_movies.sort(reverse = True)

    # Select 10 movies randomly from the filtered list of movies
    recommended_movies = cluster_movies[:10]
    # np.random.choice(cluster_movies, size=10, replace=False)

    return recommended_movies

# using k-means to recommend
def KNM_rcmd(movie):
    # Load the preprocessed movie ratings data from the "movies.csv" file
    movies_df = pd.read_csv("movie_metadata.csv")
    movies_df['movie_title'] = movies_df['movie_title'].str.lower()
    # removing the null terminating char at the end
    movies_df['movie_title'] = movies_df['movie_title'].apply(lambda x : x[:-1])

    # Preprocess data
    movies_df.drop_duplicates(inplace=True)
    movies_df.dropna(inplace=True)

    # Drop the movie titles column as we only need the ratings data
    features = ['num_critic_for_reviews', 'duration', 'director_facebook_likes', 'actor_3_facebook_likes',
            'actor_1_facebook_likes', 'gross', 'num_voted_users', 'cast_total_facebook_likes',
            'facenumber_in_poster', 'num_user_for_reviews', 'budget', 'title_year', 'actor_2_facebook_likes',
            'imdb_score', 'aspect_ratio', 'movie_facebook_likes']
    matrix = pd.get_dummies(movies_df[features]).values

    # Apply the K-means algorithm to cluster the movies based on their ratings
    kmeans = KMeans(n_clusters=10)
    kmeans.fit(matrix)

    # Add the cluster labels to the movies dataframe
    movies_df['cluster'] = kmeans.labels_

    user_movie = movie.lower()
    similar_movies = list(get_KNNrecommend_movies(user_movie,movies_df))

    return similar_movies

# Set up the Flask app
app = Flask(__name__)

# Define the home page
@app.route('/')
def home():
    return render_template('home.html')

# Define the recommendation page
@app.route('/recommendation', methods=['POST'])
def recommendation():
    movie_title = request.form['movie_title']
    CS_recommended_movies = cs_rcmd(movie_title)
    CC_recommended_movies = correlationCoefficient_rcmd(movie_title)
    KNM_recommended_movies = KNM_rcmd(movie_title)
    print("in posting",KNM_recommended_movies)
    return render_template('recommend.html', movie_title=movie_title, CS_recommended_movies=CS_recommended_movies,
                           CC_recommended_movies=CC_recommended_movies, KNM_recommended_movies=KNM_recommended_movies)

if __name__ == '__main__':
    app.run(debug=True)
